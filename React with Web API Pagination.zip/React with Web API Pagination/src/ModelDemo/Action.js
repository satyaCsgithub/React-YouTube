import React, { Component } from 'react';
import Modal from './Modal';

import axios from 'axios';
import { Table,Button } from 'react-bootstrap';
const apiUrl = 'http://localhost:50685/Api/UserReact';


class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isOpen: false,
      error: null,
      users: [],
      userData: {},
      response: {}
    };
  }

  componentDidMount(){
    axios.get(apiUrl + '/GetUserReactDetails').then(response => response.data).then(
         (result)=>{
             this.setState({
                 users:result
             });
         },
         (error)=>{
             this.setState({error});
         }
     )
 }

  toggleModal(userId) {

axios.get(apiUrl + "/GetUserReactDetailsById/" + userId).then(response => response.data).then(result => {

         this.setState({
          userData: result      
         });
       },
       (error) => {
         this.setState({ error });
       }
     )

     this.setState({
      isOpen: !this.state.isOpen
    });
 
  }

  render() {
    const{users}=this.state;
    return (
      <div className="App">
  
        <div >
<h3 class="text-bg-primary">Display user details in modal popup in ReactJS Using Web API</h3>
<div className="row">
<div className="col-md-1"></div>
<div className="col-md-10">
<Table className="table table-bordered border-primary">
                    <thead className="table-dark">
                      <tr>
                        <th>First Name</th>                     
                        <th>Email-Id</th>
                        <th>Mobile No.</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map(user => (
                        <tr key={user.UserId}>
                          <td>{user.FirstName}</td>
                     
                          <td>{user.EmailId}</td>
                          <td>{user.MobileNo}</td>
                        
                          <td><Button variant="primary" onClick={()=>this.toggleModal(user.UserId)} >Details</Button>  &nbsp;&nbsp;&nbsp;
                        
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
</div>
<div className="col-md-3"></div>
</div>
    
                  </div>
        <Modal show={this.state.isOpen}
          onClose={()=>this.toggleModal(this.UserId)}>
          <Table className="table table-bordered border-primary">
            <thead>
              <tr className="table-dark"><th colSpan="2">User Details by React</th></tr>
            </thead>
            <tbody>

              <tr>
                <th>First Name </th><td>{this.state.userData.FirstName}</td>
              </tr> <tr>
                <th>Last Name </th><td>{this.state.userData.LastName}</td>
              </tr> <tr>
                <th>EmailId  </th><td>{this.state.userData.EmailId}</td>
              </tr> <tr>
                <th>Mobile No  </th><td>{this.state.userData.MobileNo}</td>
              </tr> <tr>
                <th>Address  </th><td>{this.state.userData.Address}</td>
              </tr> <tr>
                <th>PinCode  </th><td>{this.state.userData.PinCode}</td>
              </tr>
              <tr>
                <th>Company Name  </th><td>{this.state.userData.CompanyName}</td>
              </tr>
              <tr>
                <th>Gender  </th><td>{this.state.userData.Gender}</td>
              </tr>
              <tr>
                <th>Country  </th><td>{this.state.userData.Country}</td>
              </tr>
              <tr>
                <th>State  </th><td>{this.state.userData.State}</td>
              </tr>
              <tr>
                <th>City  </th><td>{this.state.userData.City}</td>
              </tr>
            </tbody>
          </Table>
               
        </Modal>
      </div>
    );
  }
}

export default App;
