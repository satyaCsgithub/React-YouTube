import React from 'react';  
import {  
    Row,  
    Col,  
    Container  
} from 'react-bootstrap';  
import Axios from 'axios';  
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';  
import EmployeePagination from './EmployeePagination';  
import 'bootstrap/dist/css/bootstrap.css';  
const apiUrl = "http://localhost:50685/Api/Employee";  
class EmployeeList extends React.Component {  
    constructor(props) {  
        super(props);  
        this.state = {  
            error: null,  
            response: {},  
            CurrentPage: 1,  
            data: [],  
            filter: {  
                pageNo: 1,  
                sizePerPage: 5,  
            },  
            totalCount: 0,  
        }  
    }  
    componentDidMount() {  
        this.bindData();  
    }  
    bindData() {  
        let {  
            pageNo  
        } = this.state.filter;  
        Axios.get(apiUrl + `/GetEmpDetails?pageNo=${pageNo}`).then(response => response.data).then(  
            (result) => {  
                this.setState({  
                    data: result.employees,  
                    totalCount: result.TotalCount  
                });  
            },  
            (error) => {  
                this.setState({  
                    error  
                });  
            })  
    }  
    onPageHandler = async (type, {  
        page  
    }) => {  
        let data = page  
        let {  
            filter  
        } = this.state;  
        let tempFilter = {  
            ...filter  
        };  
        tempFilter["pageNo"] = data;  
        await this.setState({  
            filter: tempFilter  
        })  
        this.bindData()  
    }  
    render() {  
        //Column Style  
        const colStyle = {  
            backgroundColor: '#002b48',  
            color: "#ffffff",  
            width: '60px'  
        }  
        //Generate column  
        const columns = [{  
            dataField: 'Id',  
            text: 'Id',  
            headerStyle: colStyle  
        }, {  
            dataField: 'Name',  
            text: 'Name',  
            headerStyle: colStyle  
        }, {  
            dataField: 'Gender',  
            text: 'Gender',  
            headerStyle: colStyle  
        }, {  
            dataField: 'Salary',  
            text: 'Salary',  
            headerStyle: colStyle  
        }];  
        const {  
            filter,  
            data  
        } = this.state;  
        return ( 
        
        <React.Fragment><Container> 
        <Row><Col> 
        <br/>
        <h3 className="text-bg-primary"> Pagination In React Using ASP.NET Web API </h3>
        </Col></Row>
        <Row>
        <Col xs = {40}></Col>
        <Col xs = {80}> 
        <EmployeePagination data = {data}  
            page = {  
                filter.pageNo  
            }  
            sizePerPage = {  
                filter.sizePerPage || 5  
            }  
            totalSize = {  
                this.state.totalCount  
            }  
            onTableChange = {  
                this.onPageHandler  
            }  
            columns = {  
                columns  
            }/> 
            </Col> 
            <Col xs = {40}></Col> 
            </Row> 
            </Container> 
            </React.Fragment>)  
    }  
}  
export default EmployeeList; 