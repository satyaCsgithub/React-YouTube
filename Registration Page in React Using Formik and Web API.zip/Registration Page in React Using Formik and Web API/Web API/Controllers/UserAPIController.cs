﻿using AngularApp.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Http;

namespace AngularApp.Controllers
{
    [RoutePrefix("Api/User")]
    public class UserAPIController : ApiController
    {
        SatyaDBEntities objEntity = new SatyaDBEntities();

        [HttpGet]
        [Route("GetUserDetails")]
        public IQueryable<userdetail> GetUser()
        {
            try
            {
                return objEntity.userdetails;
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        [Route("DeleteRecord")]
        public IHttpActionResult DeleteRecord(List<userdetail> user)
        {
            string result = "";
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                result = DeleteData(user);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Ok(result);
        }
        private string DeleteData(List<userdetail> users)
        {
            string str = "";
            try
            {
                foreach (var item in users)
                {
                    userdetail obj = new userdetail();
                    obj.userid = item.userid;
                    obj.username = item.username;
                    obj.gender = item.gender;
                    obj.mobileno = item.mobileno;
                    obj.pincode = item.pincode;
                    obj.emailid = item.emailid;
                    var entry = objEntity.Entry(obj);
                    if (entry.State == EntityState.Detached) objEntity.userdetails.Attach(obj);
                    objEntity.userdetails.Remove(obj);
                }
                int i = objEntity.SaveChanges();
                if (i > 0)
                {
                    str = "Records has been deleted";
                }
                else
                {
                    str = "Records deletion has been faild";
                }
            }
            catch (Exception)
            {
                throw;
            }
            return str;
        }
    }
}
