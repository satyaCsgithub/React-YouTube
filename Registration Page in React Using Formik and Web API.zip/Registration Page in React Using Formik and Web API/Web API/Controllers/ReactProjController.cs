﻿using System;
using System.Linq;
using System.Web.Http;
using AngularApp.Models;

namespace AngularApp.Controllers
{
    [RoutePrefix("Api/UserReact")]
    public class ReactProjController : ApiController
    {
        SatyaDBEntities objEntity = new SatyaDBEntities();

        [HttpGet]
        [Route("GetUserReactDetails")]
        public IQueryable<UserDetailsReact> GetEmaployee()
        {
            try
            {
                return objEntity.UserDetailsReacts;
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpGet]
        [Route("GetUserReactDetailsById/{userId}")]
        public IHttpActionResult GetUserById(string userId)
        {
            UserDetailsReact objUser = new UserDetailsReact();
            if (userId != "undefined")
            {

                int ID = Convert.ToInt32(userId);
                try
                {
                    objUser = objEntity.UserDetailsReacts.Find(ID);
                    if (objUser == null)
                    {
                        return NotFound();
                    }

                }
                catch (Exception)
                {
                    throw;
                }
            }

            return Ok(objUser);
        }
    }
}
