﻿using System;
using System.Linq;
using System.Web.Http;
using AngularApp.Models;

namespace AngularApp.Controllers
{
    [RoutePrefix("Api/UserDetailGridCRUD")]
    public class UserDetailGridCRUDController : ApiController
    {
        SatyaDBEntities objEntity = new SatyaDBEntities();
        [HttpGet]
        [Route("GetUserDetails")] //--http://localhost:50685/Api/UserDetailGridCRUD/GetUserDetails
        public IQueryable<userdetail> GetUser()
        {
            try
            {
                return objEntity.userdetails;
            }
            catch (Exception)
            {
                throw;
            }
        }
        [HttpGet]
        [Route("GetUserDetailsById/{userId}")] //--http://localhost:50685/Api/UserDetailGridCRUD/GetUserDetailsById/1028
        public IHttpActionResult GetUserById(string userId)
        {
            userdetail objUser = new userdetail();
            int ID = Convert.ToInt32(userId);
            try
            {
                objUser = objEntity.userdetails.Find(ID);
                if (objUser == null)
                {
                    return NotFound();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Ok(objUser);
        }
        [HttpPost]
        [Route("InsertUserDetails")]
        public IHttpActionResult PostUser(userdetail data)
        {
            string message = "";
            if (data != null)
            {
                try
                {
                    objEntity.userdetails.Add(data);
                    int result = objEntity.SaveChanges();
                    if (result > 0)
                    {
                        message = "User has been successfully added";
                    }
                    else
                    {
                        message = "faild";
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return Ok(message);
        }
        [HttpPut]
        [Route("UpdateEmployeeDetails")]
        public IHttpActionResult PutUserMaster(userdetail user)
        {
            string message = "";
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                userdetail objUser = new userdetail();
                objUser = objEntity.userdetails.Find(user.userid);
                if (objUser != null)
                {
                    objUser.username = user.username;
                    objUser.emailid = user.emailid;
                    objUser.gender = user.gender;
                    objUser.address = user.address;
                    objUser.mobileno = user.mobileno;
                    objUser.pincode = user.pincode;
                }
                int result = objEntity.SaveChanges();
                if (result > 0)
                {
                    message = "User has been successfully updated";
                }
                else
                {
                    message = "faild";
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Ok(message);
        }
        [HttpDelete]
        [Route("DeleteUserDetails")]
        public IHttpActionResult DeleteEmaployeeDelete(int id)
        {
            string message = "";
            userdetail user = objEntity.userdetails.Find(id);
            objEntity.userdetails.Remove(user);
            int result = objEntity.SaveChanges();
            if (result > 0)
            {
                message = "User has been successfully deleted";
            }
            else
            {
                message = "faild";
            }
            return Ok(message);
        }
    }
}
