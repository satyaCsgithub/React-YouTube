﻿using AngularApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace AngularApp.Controllers
{
    [RoutePrefix("Api/UserRegistration")]
    public class ReactRegistrationController : ApiController
    {
        [HttpGet]
        [Route("GetUserRegistrationDetails")]
        public IEnumerable<UserRegistration> GetUser()
        {
            try
            {
                SatyaDBEntities1 objEntity = new SatyaDBEntities1();
                return objEntity.UserRegistrations.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        [Route("InsertUserRegistrationData")]
        public string AddUserData(UserRegistration data)
        {
            string message = "";
            try
            {
                SatyaDBEntities1 objEntity = new SatyaDBEntities1();
                objEntity.UserRegistrations.Add(data);
                int result = objEntity.SaveChanges();
                if (result > 0)
                {

                    message = string.Format("The data has been successfully added for user {0} {1}", data.FirstName, data.LastName);
                }
                else
                {
                    message = string.Format("The data is failed to insert the user {0} {1}", data.FirstName, data.LastName + "" + "Please check Web API is running or not!");
                }

            }
            catch (Exception)
            {
                throw;
            }

            return message;
        }
    }
}
