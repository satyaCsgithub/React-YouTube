import React from 'react';
import { Row, Form, Col, Button } from 'react-bootstrap';


class AddUser extends React.Component {
  constructor(props) {
    super(props);

    this.initialState = {
      UserId: '',
      FirstName: '',
      firstNameError: '',
      LastName: '',
      LastNameError: '',
      EmailId: '',
      MobileNo: '',
      Address: '',
      PinCode: '',
    }

    if (props.user.UserId) {
      this.state = props.user
    } else {
      this.state = this.initialState;
    }

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

  }

  handleChange(event) {
    const name = event.target.name;
    const value = event.target.value;

    this.setState({
      [name]: value,
      // Clear the error message as the user types
      firstNameError: '',
      LastNameError: ''
    })
  }

  handleSubmit(event) {
    event.preventDefault();
    // Perform validation
    if (this.state.FirstName.trim() === '') {
      this.setState({
        firstNameError: 'First Name is required.',
      });
      return; // Stop the function from proceeding
    }
    if (this.state.LastName.trim() === '') {
      this.setState({
        LastNameError: 'Last Name is required.',
      });
      return; // Stop the function from proceeding
    }
    this.props.onFormSubmit(this.state);
    this.setState(this.initialState);
  }
  render() {
    let pageTitle;
    let actionStatus;
    if (this.state.UserId) {

      pageTitle = <h2>Edit User</h2>
      actionStatus = <b>Update</b>
    } else {
      pageTitle = <h2>Create New User</h2>
      actionStatus = <b>Submit</b>
    }

    return (
      <div>
        <h2> {pageTitle}</h2>
        <Row>
          <Col sm={7}>
            <Form onSubmit={this.handleSubmit}>
              <Form.Group controlId="FirstName">
                <Form.Label>First Name</Form.Label>
                <Form.Control
                  type="text"
                  name="FirstName"
                  value={this.state.FirstName}
                  onChange={this.handleChange}
                  placeholder="First Name"
                  isInvalid={!!this.state.firstNameError}
                />
                <Form.Control.Feedback type="invalid">
                  {this.state.firstNameError}
                </Form.Control.Feedback>
              </Form.Group>
              <Form.Group controlId="LastName">
                <Form.Label>Last Name</Form.Label>
                <Form.Control
                  type="text"
                  name="LastName"
                  value={this.state.LastName}
                  onChange={this.handleChange}
                  placeholder="Last Name"
                  isInvalid={!!this.state.LastNameError}
                />
                <Form.Control.Feedback type="invalid">
                  {this.state.LastNameError}
                </Form.Control.Feedback>
              </Form.Group>
              <Form.Group controlId="EmailId">
                <Form.Label>EmailId</Form.Label>
                <Form.Control
                  type="text"
                  name="EmailId"
                  value={this.state.EmailId}
                  onChange={this.handleChange}
                  placeholder="EmailId" />
              </Form.Group>
              <Form.Group controlId="MobileNo">
                <Form.Label>MobileNo</Form.Label>
                <Form.Control
                  type="text"
                  name="MobileNo"
                  value={this.state.MobileNo}
                  onChange={this.handleChange}
                  placeholder="MobileNo" />
              </Form.Group>
              <Form.Group controlId="Address">
                <Form.Label>Address</Form.Label>
                <Form.Control
                  type="text"
                  name="Address"
                  value={this.state.Address}
                  onChange={this.handleChange}
                  placeholder="Address" />
              </Form.Group>

              <Form.Group controlId="PinCode">
                <Form.Label>PinCode</Form.Label>
                <Form.Control
                  type="text"
                  name="PinCode"
                  value={this.state.PinCode}
                  onChange={this.handleChange}
                  placeholder="PinCode" />
              </Form.Group>
              <Form.Group>
                <Form.Control type="hidden" name="UserId" value={this.state.UserId} />
                <br />
                <Button variant="success" type="submit">{actionStatus}</Button>

              </Form.Group>
            </Form>
          </Col>
        </Row>
      </div>
    )
  }
}

export default AddUser;