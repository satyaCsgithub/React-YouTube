import React from 'react';
import './App.css';
import Action from './ModelDemo/Action';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
     <Action/>
    </div>
  );
}

export default App;