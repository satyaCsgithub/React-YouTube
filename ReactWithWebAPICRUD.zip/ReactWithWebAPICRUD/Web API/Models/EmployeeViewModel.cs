﻿using System.Collections.Generic;

namespace AngularApp.Models
{
    public class EmployeeViewModel
    {
        public int TotalCount
        {
            get;
            set;
        }
        public IEnumerable<Employee> employees
        {
            get;
            set;
        }
    }
}