﻿using AngularApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AngularApp.Controllers
{
    [RoutePrefix("Api/ReactCRUD")]
    public class ReactCRUDApiController : ApiController
    {
        SatyaDBEntities1 objEntity = new SatyaDBEntities1();

        [HttpGet]
        [Route("GetUserDetails")] //--http://localhost:50685/Api/ReactCRUD/GetUserDetails
        public IQueryable<UserDetailCRUD> GetEmaployee()
        {
            try
            {
                return objEntity.UserDetailCRUDs;
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpGet]
        [Route("GetUserDetailsById/{userId}")]
        public IHttpActionResult GetUserById(string userId)
        {
            UserDetailCRUD objUser = new UserDetailCRUD();
            int ID = Convert.ToInt32(userId);
            try
            {
                objUser = objEntity.UserDetailCRUDs.Find(ID);
                if (objUser == null)
                {
                    return NotFound();
                }

            }
            catch (Exception)
            {
                throw;
            }

            return Ok(objUser);
        }

        [HttpPost]
        [Route("InsertUserDetails")]
        public IHttpActionResult PostUser(UserDetailCRUD data)
        {
            string message = "";
            if (data != null)
            {

                try
                {
                    objEntity.UserDetailCRUDs.Add(data);
                    int result = objEntity.SaveChanges();
                    if (result > 0)
                    {
                        message = string.Format("The data has been successfully added for user {0} {1}", data.FirstName, data.LastName);
                    }
                    else
                    {
                        message = string.Format("The data is failed to add for user {0} {1}", data.FirstName, data.LastName);
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }

            return Ok(message);
        }

        [HttpPut]
        [Route("UpdateEmployeeDetails")]
        public IHttpActionResult PutUserMaster(UserDetailCRUD user)
        {
            string message = "";
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                UserDetailCRUD objUser = new UserDetailCRUD();
                objUser = objEntity.UserDetailCRUDs.Find(user.UserId);
                if (objUser != null)
                {
                    objUser.FirstName = user.FirstName;
                    objUser.LastName = user.LastName;
                    objUser.EmailId = user.EmailId;
                    objUser.MobileNo = user.MobileNo;
                    objUser.Address = user.Address;
                    objUser.PinCode = user.PinCode;

                }

                int result = objEntity.SaveChanges();
                if (result > 0)
                {
                    message = string.Format("The data has been successfully updated for user {0} {1}", objUser.FirstName, objUser.LastName);
                }
                else
                {
                    message = string.Format("There is no update for user {0} {1}", objUser.FirstName, objUser.LastName);
                }

            }
            catch (Exception)
            {
                throw;
            }

            return Ok(message);
        }

        [HttpDelete]
        [Route("DeleteUserDetails/{id}")]
        public IHttpActionResult DeleteUserDelete(int id)
        {
            string message = "";
            UserDetailCRUD user = objEntity.UserDetailCRUDs.Find(id);
            if (user == null)
            {
                return NotFound();
            }

            objEntity.UserDetailCRUDs.Remove(user);
            int result = objEntity.SaveChanges();
            if (result > 0)
            {
                message = string.Format("The data has been sussfully deleted for user {0} {1}", user.FirstName, user.LastName);
            }
            else
            {
                message = string.Format("The data is failed to delete for user {0} {1}", user.FirstName, user.LastName);
            }

            return Ok(message);
        }
    }
}
