﻿using ExcelDataReader;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using AngularApp.Models;
using System;
using System.Threading.Tasks;

namespace AngularApp.Controllers
{
    [RoutePrefix("Api/Excel")]
    public class ExcelUploadController : ApiController
    {
        [HttpPost]
        [Route("UploadExcel")]
        public string ExcelUpload()
        {
            string message = "";
            HttpResponseMessage result = null;
            var httpRequest = HttpContext.Current.Request;
            using (SatyaDBEntities objEntity = new SatyaDBEntities())
            {

                if (httpRequest.Files.Count > 0)
                {
                    HttpPostedFile file = httpRequest.Files[0];
                    Stream stream = file.InputStream;

                    IExcelDataReader reader = null;

                    if (file.FileName.EndsWith(".xls"))
                    {
                        reader = ExcelReaderFactory.CreateBinaryReader(stream);
                    }
                    else if (file.FileName.EndsWith(".xlsx"))
                    {
                        reader = ExcelReaderFactory.CreateOpenXmlReader(stream);
                    }
                    else
                    {
                        message = "This file format is not supported";
                    }

                    DataSet excelRecords = reader.AsDataSet();
                    reader.Close();

                    var finalRecords = excelRecords.Tables[0];
                    for (int i = 0; i < finalRecords.Rows.Count; i++)
                    {
                        userdetail objUser = new userdetail();
                        objUser.username = finalRecords.Rows[i][0].ToString();
                        objUser.emailid = finalRecords.Rows[i][1].ToString();
                        objUser.gender = finalRecords.Rows[i][2].ToString();
                        objUser.address = finalRecords.Rows[i][3].ToString();
                        objUser.mobileno = finalRecords.Rows[i][4].ToString();
                        objUser.pincode = finalRecords.Rows[i][5].ToString();

                        objEntity.userdetails.Add(objUser);

                    }

                    int output = objEntity.SaveChanges();
                    if (output > 0)
                    {
                        message = "Excel file has been successfully uploaded";
                    }
                    else
                    {
                        message = "Excel file uploaded has failed";
                    }

                }

                else
                {
                    result = Request.CreateResponse(HttpStatusCode.BadRequest);
                }
            }
            return message;
        }

        [HttpGet]
        [Route("UserDetails")]
        public List<userdetail> BindUser()
        {
            List<userdetail> lstUser = new List<userdetail>();
            using (SatyaDBEntities objEntity = new SatyaDBEntities())
            {
                lstUser = objEntity.userdetails.ToList();
            }
            return lstUser;
        }

        [RoutePrefix("Api/UserAPI")]
        public class UserController : ApiController
        {
            [HttpGet]
            [Route("AllUser")]
            public IEnumerable<userdetail> UserDetails()
            {
                IEnumerable<userdetail> lstUser = new List<userdetail>();
                string response = "";
                try
                {
                    using (SatyaDBEntities objEntity = new SatyaDBEntities())
                    {
                        lstUser = objEntity.userdetails.ToList();
                    }
                }
                catch (Exception ex)
                {
                    response = ex.ToString();
                }
                return lstUser;
            }
        }

        //add
        //http://localhost:50685/Api/ScrollAPI/ScrollAllUserDetails?pageNumber=1
        [RoutePrefix("Api/ScrollAPI")]
        public class ScrollUserController : ApiController
        {
            [HttpGet]
            [Route("ScrollAllUserDetails")]
            public Task<IEnumerable<userdetail>> ScrollAllUser(int pageNumber)
            {
                IEnumerable<userdetail> lstUser = new List<userdetail>();
                pageNumber = pageNumber * 10;
                try
                {
                    using (SatyaDBEntities objEntity = new SatyaDBEntities())
                    {

                        lstUser = objEntity.userdetails.Take(pageNumber).ToList();
                    }

                }
                catch (Exception)
                {
                    throw;
                }

                return Task.Run(() => lstUser);

            }
        }
        //add
    }
}
