﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using AngularApp.Models;

namespace AngularApp.Controllers
{
    [RoutePrefix("Api/BranchAPI")]
    public class BranchController : ApiController
    {
        [HttpGet]
        [Route("AllBranch")]
        public IEnumerable<BranchDetail> BranchDetails()
        {
            IEnumerable<BranchDetail> lstBranch = new List<BranchDetail>();
            string response = "";
            try
            {
                using (SatyaDBEntities1 objEntity = new SatyaDBEntities1())
                {
                    lstBranch = objEntity.BranchDetails.ToList();
                }
            }
            catch (Exception ex)
            {
                response = ex.ToString();
            }
            return lstBranch;
        }

        [HttpPost]
        [Route("AddCompanyDetails")]
        public string AddCompany(CompanyDetail companyDetails)
        {

            string response = "";
            try
            {
                using (SatyaDBEntities1 objEntity = new SatyaDBEntities1())
                {
                    objEntity.CompanyDetails.Add(companyDetails);
                    int result = objEntity.SaveChanges();
                    if (result > 0)
                    {
                        response = "Record is inserted successfully!";
                    }
                    else
                    {
                        response = "Insert record is faild";
                    }
                }
            }
            catch (Exception ex)
            {
                response = ex.ToString();
            }
            return response;
        }


        //--http://localhost:50685/Api/BranchAPI/CountryDetails
        //--http://localhost:50685/Api/BranchAPI/StateDetails/101
        //--http://localhost:50685/Api/BranchAPI/StateDetails/102
        //--http://localhost:50685/Api/BranchAPI/CityDetails/201
        //--http://localhost:50685/Api/BranchAPI/CityDetails/202
        [Route("CountryDetails")]
        [HttpGet]
        public List<Country_Details> BindCountry()
        {
            IEnumerable<Country_Details> lstCountry = new List<Country_Details>();
            try
            {
                using (SatyaDBEntities2 objEntity = new SatyaDBEntities2())
                {
                    lstCountry = objEntity.Country_Details.ToList();

                }
            }
            catch (Exception)
            {
                throw;
            }

            return lstCountry.ToList();

        }

        [Route("StateDetails/{counryId}")]
        [HttpGet]
        public List<State_Details> BindState(string counryId)
        {
            IEnumerable<State_Details> lstState = new List<State_Details>();
            try
            {
                using (SatyaDBEntities2 objEntity = new SatyaDBEntities2())
                {
                    lstState = objEntity.State_Details.Where(a => a.Country_Code == counryId).ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return lstState.ToList();

        }

        [Route("CityDetails/{cityId}")]
        [HttpGet]
        public List<District_Details> BindCity(string cityId)
        {
            IEnumerable<District_Details> lstDistrict = new List<District_Details>();
            try
            {
                using (SatyaDBEntities2 objEntity = new SatyaDBEntities2())
                {

                    lstDistrict = objEntity.District_Details.Where(a => a.State_Code == cityId).ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return lstDistrict.ToList();
        }
    }
}