﻿using System;
using System.Linq;
using System.Web.Http;
using AngularApp.Models;
namespace AngularApp.Controllers
{
    [RoutePrefix("Api/Employee")]
    public class EmployeeAPIController : ApiController
    {
        //--http://localhost:50685/Api/Employee/GetEmpDetails?pageNo=2
        [HttpGet]
        [Route("GetEmpDetails")]
        public EmployeeViewModel GetEmaployee(int pageNo)
        {
            int skipPage = (pageNo - 1) * 5;
            EmployeeViewModel objEmp = new EmployeeViewModel();
            try
            {
                SatyaDBEntities objEntity = new SatyaDBEntities();
                int totalCount = objEntity.Employees.Count();
                var result = objEntity.Employees.OrderBy(a => a.Id).Skip(skipPage).Take(5).ToList();
                objEmp.TotalCount = totalCount;
                objEmp.employees = result;
                return objEmp;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}