import React, { Component } from 'react';

import { Container, Button } from 'react-bootstrap';
import UserList from './GetUser';
import AddUser from './AddUser';
import axios from 'axios';
const apiUrl = 'http://localhost:50685/Api/ReactCRUD/';

class UserActionApp extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isAddUser: false,
      error: null,
      response: {},
      userData: {},
      isEdituser: false,
      isUserDetails: true,
    }

    this.onFormSubmit = this.onFormSubmit.bind(this);

  }

  //Show Alert

  showAlert(message, type) {
    const alertPlaceholder = document.getElementById('alert-container');
    const wrapper = document.createElement('div');
    wrapper.innerHTML = [
      `<div class="alert alert-${type} alert-dismissible fade show" role="alert">`,
      `   <div>${message}</div>`,
      '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
      '</div>'
    ].join('');

    alertPlaceholder.append(wrapper);

    // Automatically hide the alert after 10 seconds
    setTimeout(() => {
      wrapper.remove();
    }, 10000);
  }

  //Show Alert

  onCreate() {
    this.setState({ isAddUser: true });
    this.setState({ isUserDetails: false });
  }
  onDetails() {
    this.setState({ isUserDetails: true });
    this.setState({ isAddUser: false });
  }

  onFormSubmit(data) {
    this.setState({ isAddUser: true });
    this.setState({ isUserDetails: false });
    if (this.state.isEdituser) {
      axios.put(apiUrl + 'UpdateEmployeeDetails', data).then(result => {
        this.showAlert(result.data, 'success');
        //alert(result.data);
        this.setState({
          response: result,
          isAddUser: false,
          isEdituser: false
        })
      });
    } else {

      axios.post(apiUrl + 'InsertUserDetails', data).then(result => {
        this.showAlert(result.data, 'success');
        //alert(result.data);
        this.setState({
          response: result,
          isAddUser: false,
          isEdituser: false
        })
      });
    }

  }

  editUser = userId => {

    this.setState({ isUserDetails: false });
    axios.get(apiUrl + "GetUserDetailsById/" + userId).then(result => {

      this.setState({
        isEdituser: true,
        isAddUser: true,
        userData: result.data
      });
    },
      (error) => {
        this.setState({ error });
      }
    )

  }


  render() {

    let userForm;
    if (this.state.isAddUser || this.state.isEditUser) {

      userForm = <AddUser onFormSubmit={this.onFormSubmit} user={this.state.userData} />

    }


    return (
      <><div className="App">
        <Container>
          <h1 style={{ textAlign: 'center', color: 'green' }}>CURD operation in React using Web API</h1>
          <hr></hr>
          {!this.state.isUserDetails && <Button variant="primary" onClick={() => this.onDetails()}> Show User Details</Button>}
          &nbsp;
          {!this.state.isAddUser && <Button variant="success" onClick={() => this.onCreate()}>Add New User</Button>}
          <br></br>
          {!this.state.isAddUser && <UserList editUser={this.editUser} />}
          {userForm}
        </Container>
      </div><div id="alert-container"></div></>
    );
  }
}
export default UserActionApp;