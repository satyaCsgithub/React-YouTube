// import React from 'react';
// import './App.css';
// import Action from './ModelDemo/Action';
// import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

// function App() {
//   return (
//     <div className="App">
//      <Action/>
//     </div>
//   );
// }

// export default App;

//-------------------------------------------------------------------//

// import React from 'react';  
// import './App.css';  
// import EmployeeList from './ModelDemo/EmployeeList';  
// function App() {  
//    return (  
//       <div className="App">  
//          <EmployeeList/>  
//       </div>  
//       );  
//    }  
// export default App; 

//-------------------------------------------------------------------//

import React from 'react';
import './App.css';
import { Container } from 'react-bootstrap';
import UserActionApp from './UserCRUD/UserAction';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
function App() {
  return (
    <div className="App">
       <Container>      
          <UserActionApp />
        </Container>
    </div>
  );
}

export default App;
